from newsapi import NewsApiClient
import requests
import nltk
from nltk.corpus import stopwords 
from nltk.tokenize import word_tokenize, sent_tokenize
# Init
newsapi = NewsApiClient(api_key='ec2612be286747bd8097390817ec274a')

# /v2/top-headlines
for o in range(2,9,1):
    try:
        top_headlines = newsapi.get_top_headlines(category='business',
                                                  language='en')
        topurl = 'https://newsapi.org/v2/top-headlines?sources=business-insider&apiKey=ec2612be286747bd8097390817ec274a'
        toph= requests.get(topurl)
        print(toph)
        topou=toph.json()
        finar = topou['articles']
        findes = finar[o]['description']
        #print(findes)
        #print(type(findes))
        try:
            mo=finar[o]['title']
            fni = "Int Title"+str(o+1)+".txt"
            intfile = open(fni,"w")
            intfile.write(mo)
            no=finar[o]['url']
            fni1 = "Int URL"+str(o+1)+".txt"
            intfile1 = open(fni1,"w")
            intfile1.write(no)
        except:
            continue
        sentences = nltk.sent_tokenize(findes)
        lis=[]
        for sentence in sentences:
                words = nltk.word_tokenize(sentence)
                words = [word for word in words if word not in set(stopwords.words('english'))]
                tagged = nltk.pos_tag(words)
                for (word, tag) in tagged:
                    if tag == 'NNP': # If the word is a proper noun
                        print(word)
                        lis.append(word)
        print(lis)

        keywords = lis
        url = ('https://newsapi.org/v2/everything?q=' + ' AND '.join(keywords)) + '&language=en' + '&apiKey=' + '4aead031e0dc44e19e46a23add177553' + '&sortBy=relevancy' + '&pageSize=100'
        res = requests.get(url)# /v2/top-headlines/sources
        print(res)
        print(res.json()['totalResults'])
        y = res.json()['articles']
        for i in range(0,4):
            try:
                x=y[i]['title']
                filename = "title of news_"+str(i+1)+ "."+str(o+1)+".txt"
                t = open(filename,'w')
                t.write(x)
                print(x)
            except:
                continue
        for j in range(0,4):
            try:
                z=y[j]['url']
                filename1 = "url of news_"+str(j+1)+"."+str(o+1)+".txt"
                u = open(filename1,'w')
                u.write(z)
                print(z)
            except:
                continue
    except:
            continue
